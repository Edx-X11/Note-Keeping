// This program allows the user to add notes with an index and content. 
// The user can add notes indefinitely until they choose to stop by typing 'exit'.
// The program then displays the added notes and exports them to a text file named 'notes.txt'.

use std::fs::File;
use std::io::prelude::*;

struct Note {
    index: u32,
    content: String,
}

struct NoteKeepingProgram {
    notes: Vec<Note>,
}

impl NoteKeepingProgram {
    fn new() -> NoteKeepingProgram {
        NoteKeepingProgram { notes: Vec::new() }
    }

    fn add_note(&mut self, index: u32, content: String) {
        let note = Note { index, content };
        self.notes.push(note);
    }

    fn display_notes(&self) {
        for note in &self.notes {
            println!("{}: {}", note.index, note.content);
        }
    }

    fn export_notes_to_file(&self, filename: &str) {
        let mut file = File::create(filename).expect("Unable to create file");

        for note in &self.notes {
            let note_str = format!("{}: {}\n", note.index, note.content);
            file.write_all(note_str.as_bytes()).expect("Unable to write data");
        }
    }

    fn add_note_from_input(&mut self) {
        use std::io;

        loop {
            println!("Enter the index for the note (or type 'exit' to stop adding notes):");
            let mut index_input = String::new();
            io::stdin().read_line(&mut index_input).expect("Failed to read line");
            if index_input.trim() == "exit" {
                break;
            }
            let index: u32 = index_input.trim().parse().expect("Please enter a valid number");

            println!("Enter the content for the note:");
            let mut content = String::new();
            io::stdin().read_line(&mut content).expect("Failed to read line");

            self.add_note(index, content);
        }
    }
}

fn main() {
    let mut note_program = NoteKeepingProgram::new();

    note_program.add_note_from_input();

    note_program.display_notes();

    note_program.export_notes_to_file("notes.txt");
}